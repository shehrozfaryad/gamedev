using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CustomRotation : MonoBehaviour
{
    [SerializeField] private Vector3 _rotationSpeeds;

    [SerializeField] private Vector3 _rotationAxes;

    void Update()
    {
        float xRotation = _rotationSpeeds.x * _rotationAxes.x * Time.deltaTime;
        float yRotation = _rotationSpeeds.y * _rotationAxes.y * Time.deltaTime;
        float zRotation = _rotationSpeeds.z * _rotationAxes.z * Time.deltaTime;

        transform.Rotate(xRotation, yRotation, zRotation);
    }
}
